
/**
 * In this class, PremiumMember is a subclass of the GymMember class. It has five attributes:
 * premiumCharge, personalTrainer, isFullPayment, paidAmount, and discountAmount.
 * The constructor accepts nine parameters: id, name, location, phone, email, gender, DOB, membershipStartDate, and personalTrainer.
 * It calls the constructor of the superclass (GymMember) with the first eight parameters. 
 * The remaining attributes are assigned default values as described.
 */
public class PremiumMember extends GymMember
 {
    //Attributes
    private final double PREMIUM_CHARGE = 50000;
    private String personalTrainer;
    private boolean isFullPayment;
    private double paidAmount;
    private double discountAmount;

    //constructor
    public PremiumMember(int id, String name, String location, String phone, String email,
                    String gender, String dob, String membershipStartDate, 
                    String personalTrainer)
    {
       super(id, name, location, phone, email, gender, dob, membershipStartDate);
       this.personalTrainer = personalTrainer;
       this.isFullPayment = false;
       this.paidAmount = 0.0;
       this.discountAmount = 0.0;
    }

    //Getters methods
    public String getPersonalTrainer() 
    {
        return personalTrainer;
    }

    public boolean isFullPayment()
    {
        return isFullPayment;
    }

    public double getPaidAmount() 
    {
        return paidAmount;
    }

    public double getDiscountAmount()
    {
        return discountAmount;
    }
    public void markAttendance()
    {
        attendance ++;
    loyaltyPoints +=10;
    }

    // Method to pay due amount
    public String payDueAmount(double amount) 
    {
        if (isFullPayment)
        {
            return ".Payment has been fulled";
        }
        
        if (paidAmount + amount > PREMIUM_CHARGE)
        {
            return "Amount exceeds the premium charge. Payment not accepted.";
        }

        paidAmount += amount;

        if (paidAmount == PREMIUM_CHARGE) 
        {
            isFullPayment = true;
            discountAmount = 0.10 * PREMIUM_CHARGE; 
            return "Payment successful. Remaining amount: 0.0. Discount applied: " + discountAmount;
        } else if (paidAmount < PREMIUM_CHARGE) 
        {
            return "Full payment received. Remaining amount: " + (PREMIUM_CHARGE - paidAmount);
        } else 
        {
            return "Invalid payment amount.";
        }
    }

    // Method to calculate discount
    public void calculateDiscount() 
    {
        if (isFullPayment)
        {
            discountAmount = 0.10 * PREMIUM_CHARGE;
            System.out.println("Discount applied: " + discountAmount);
        } else
        {
            System.out.println("No discount available cause full payment has not been received.");
        }
    }

    // Method to revert PremiumMember
    public void revertPremiumMember()
    {
        super.resetMember(); 
        this.personalTrainer = "";
        this.isFullPayment = false;
        this.paidAmount = 0.0;
        this.discountAmount = 0.0;
    }

    // Method to display the details
    public void display() 
    {
        super.display(); 
        System.out.println("Personal Trainer: " + personalTrainer);
        System.out.println("Paid Amount: " + paidAmount);
        System.out.println("Full Payment Status: " + (isFullPayment ? "Yes" : "No"));
        double remainingAmount = PREMIUM_CHARGE - paidAmount;
        System.out.println("Remaining Amount: " + remainingAmount);
        if (isFullPayment) 
        {
            System.out.println("Discount Amount: " + discountAmount);
        }
    }
}

