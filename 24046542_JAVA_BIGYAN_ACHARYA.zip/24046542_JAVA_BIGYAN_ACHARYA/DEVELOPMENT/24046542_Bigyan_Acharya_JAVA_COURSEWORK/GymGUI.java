/**
 * The GymManagementSystem is a Java Swing application designed to manage gym memberships through an intuitive GUI. 
 * It supports both regular and premium members, storing details such as ID, name, contact information, gender, and membership dates. 
 * Key functionalities include adding, activating, and deactivating members, tracking attendance, and converting between membership types.
 * Built with object-oriented principles, the system uses an ArrayList to store member data, enforces data validation to prevent duplicate-
 * -IDs, and employs JOptionPane for user-friendly error handling.
 * The interface features input fields, radio buttons, date selectors, and a dynamic pricing panel, with a scrollable text area to display all members.
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.awt.LayoutManager;
public class GymGUI extends JFrame 
{
    private ArrayList<GymMember> members = new ArrayList<>();
    private JFrame frame;
    private JTextField idField, nameField, locationField, phoneField, emailField, referralSourceField, paidAmountField, removalReasonField,trainerNameField;
    private JTextField regularPriceField, premiumChargeField, discountAmountField;
    private JRadioButton maleRadio, femaleRadio, otherRadio;
    private JComboBox<String> dobYearCombo, dobMonthCombo, dobDayCombo;
    private JComboBox<String> msYearCombo, msMonthCombo, msDayCombo;
    private JComboBox<String> planCombo;
    private ButtonGroup genderGroup;
    private JButton addRegularBtn, addPremiumBtn, activateBtn, deactivateBtn, markAttendanceBtn;
    private JButton revertRegularBtn, revertPremiumBtn, displayBtn, clearBtn;
    private JButton calculateDiscountBtn, payDueAmountBtn, saveToFileBtn;

    public GymGUI() 
    {
        createGUI();
    }

    private void createGUI() 
    {
        frame = new JFrame("GymGUI");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(950, 550);
        frame.setLayout(null);

        // Member Information Section
        JLabel idLabel = new JLabel("Member ID:");
        idLabel.setBounds(20, 20, 100, 25);
        frame.add(idLabel);

        idField = new JTextField();
        idField.setBounds(150, 20, 150, 25);
        frame.add(idField);

        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setBounds(20, 60, 100, 25);
        frame.add(nameLabel);

        nameField = new JTextField();
        nameField.setBounds(150, 60, 150, 25);
        frame.add(nameField);

        JLabel locationLabel = new JLabel("Location:");
        locationLabel.setBounds(20, 100, 100, 25);
        frame.add(locationLabel);

        locationField = new JTextField();
        locationField.setBounds(150, 100, 150, 25);
        frame.add(locationField);

        JLabel phoneLabel = new JLabel("Phone:");
        phoneLabel.setBounds(20, 140, 100, 25);
        frame.add(phoneLabel);

        phoneField = new JTextField();
        phoneField.setBounds(150, 140, 150, 25);
        frame.add(phoneField);

        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setBounds(20, 180, 100, 25);
        frame.add(emailLabel);

        emailField = new JTextField();
        emailField.setBounds(150, 180, 150, 25);
        frame.add(emailField);

        JLabel genderLabel = new JLabel("Gender:");
        genderLabel.setBounds(20, 220, 100, 25);
        frame.add(genderLabel);

        maleRadio = new JRadioButton("Male");
        femaleRadio = new JRadioButton("Female");
        otherRadio = new JRadioButton("Other");
        genderGroup = new ButtonGroup();
        genderGroup.add(maleRadio);
        genderGroup.add(femaleRadio);
        genderGroup.add(otherRadio);
        maleRadio.setBounds(150, 220, 60, 25);
        femaleRadio.setBounds(220, 220, 80, 25);
        otherRadio.setBounds(310, 220, 80, 25);
        frame.add(maleRadio);
        frame.add(femaleRadio);
        frame.add(otherRadio);
        
        

        // Date of Birth Section
        JLabel dobLabel = new JLabel("Date of Birth:");
        dobLabel.setBounds(500, 20, 120, 25);
        frame.add(dobLabel);

        dobYearCombo = new JComboBox<>();
        for (int i = 2023; i >= 1924; i--) dobYearCombo.addItem(String.valueOf(i));
        dobYearCombo.setBounds(620, 20, 80, 25);
        frame.add(dobYearCombo);

        dobMonthCombo = new JComboBox<>(new String[]{"01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"});
        dobMonthCombo.setBounds(720, 20, 60, 25);
        frame.add(dobMonthCombo);

        dobDayCombo = new JComboBox<>();
        for (int i = 1; i <= 31; i++) dobDayCombo.addItem(String.format("%02d", i));
        dobDayCombo.setBounds(800, 20, 60, 25);
        frame.add(dobDayCombo);

        // Membership Start Date Section
        JLabel msLabel = new JLabel("Membership Start:");
        msLabel.setBounds(500, 60, 120, 25);
        frame.add(msLabel);

        msYearCombo = new JComboBox<>();
        for (int i = 2023; i >= 2000; i--) msYearCombo.addItem(String.valueOf(i));
        msYearCombo.setBounds(620, 60, 80, 25);
        frame.add(msYearCombo);

        msMonthCombo = new JComboBox<>(new String[]{"01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"});
        msMonthCombo.setBounds(720, 60, 60, 25);
        frame.add(msMonthCombo);

        msDayCombo = new JComboBox<>();
        for (int i = 1; i <= 31; i++) msDayCombo.addItem(String.format("%02d", i));
        msDayCombo.setBounds(800, 60, 60, 25);
        frame.add(msDayCombo);

        // Additional Fields
        JLabel referralLabel = new JLabel("Referral Source:");
        referralLabel.setBounds(500, 100, 120, 25);
        frame.add(referralLabel);

        referralSourceField = new JTextField();
        referralSourceField.setBounds(620, 100, 150, 25);
        frame.add(referralSourceField);

        JLabel trainerLabel = new JLabel("Trainer Name:");
        trainerLabel.setBounds(500, 140, 120, 25);
        frame.add(trainerLabel);

        trainerNameField = new JTextField();
        trainerNameField.setBounds(620, 140, 150, 25);
        frame.add(trainerNameField);

        JLabel removalLabel = new JLabel("Removal Reason:");
        removalLabel.setBounds(500, 180, 120, 25);
        frame.add(removalLabel);

        removalReasonField = new JTextField();
        removalReasonField.setBounds(620, 180, 150, 25);
        frame.add(removalReasonField);

        // Pricing Panel
        JPanel pricingPanel = new JPanel();
        pricingPanel.setLayout(null);
        pricingPanel.setBounds(490, 190, 400, 150);
        
     

        JLabel regularLabel = new JLabel("Regular Plan Price:");
        regularLabel.setBounds(10, 30, 150, 25);
        pricingPanel.add(regularLabel);

        regularPriceField = new JTextField("6500");
        regularPriceField.setBounds(170, 30, 100, 25);
        regularPriceField.setEditable(false);
        pricingPanel.add(regularPriceField);

        JLabel premiumLabel = new JLabel("Premium Charge:");
        premiumLabel.setBounds(10, 70, 150, 25);
        pricingPanel.add(premiumLabel);

        premiumChargeField = new JTextField("50000");
        premiumChargeField.setBounds(170, 70, 100, 25);
        premiumChargeField.setEditable(false);
        pricingPanel.add(premiumChargeField);

        JLabel discountLabel = new JLabel("Discount Amount:");
        discountLabel.setBounds(10, 110, 150, 25);
        pricingPanel.add(discountLabel);

        discountAmountField = new JTextField("0");
        discountAmountField.setBounds(170, 110, 100, 25);
        discountAmountField.setEditable(false);
        pricingPanel.add(discountAmountField);
        
        // Membership Plan Section
        JLabel planLabel = new JLabel("Membership Plan:");
        planLabel.setBounds(20, 260, 120, 25);
        frame.add(planLabel);
        
        planCombo = new JComboBox<>(new String[]{"Basic", "Standard", "Deluxe"});
        planCombo.setBackground(Color.WHITE);
        planCombo.setBounds(150, 260, 200, 30);
        frame.add(planCombo);


        frame.add(pricingPanel);

        // Add the button panel
        JPanel buttonPanel = createButtonPanel();
        buttonPanel.setBounds(20, 360, 900, 150);
        frame.add(buttonPanel);

        frame.setVisible(true);
    }
    
    private JPanel createButtonPanel() 
    {
        JPanel panel = new JPanel(new GridLayout(2, 1, 5, 5));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10,10,10));
        
        addRegularBtn = new JButton("Add Regular Member");
        addRegularBtn.addActionListener(e -> addRegularMember());
        panel.add(addRegularBtn);
        
        addPremiumBtn = new JButton("Add Premium Member");
        addPremiumBtn.addActionListener(e -> addPremiumMember());
        panel.add(addPremiumBtn);
        
        activateBtn = new JButton("Activate Membership");
        activateBtn.addActionListener(e -> activateMembership());
        panel.add(activateBtn);
        
        deactivateBtn = new JButton("Deactivate Membership");
        deactivateBtn.addActionListener(e -> deactivateMembership());
        panel.add(deactivateBtn);
        
        markAttendanceBtn = new JButton("Mark Attendance");
        markAttendanceBtn.addActionListener(e -> markAttendance());
        panel.add(markAttendanceBtn);
        
        revertRegularBtn = new JButton("Revert Regular Member");
        revertRegularBtn.addActionListener(e -> revertRegularMember());
        panel.add(revertRegularBtn);
        
        revertPremiumBtn = new JButton("Revert Premium Member");
        revertPremiumBtn.addActionListener(e -> revertPremiumMember());
        panel.add(revertPremiumBtn);
        
        displayBtn = new JButton("Display Members");
        displayBtn.addActionListener(e -> displayMembers());
        panel.add(displayBtn);
        
        clearBtn = new JButton("Clear Fields");
        clearBtn.addActionListener(e -> clearFields());
        panel.add(clearBtn);
        
        calculateDiscountBtn = new JButton("Calculate Discount");
        calculateDiscountBtn.addActionListener(e -> calculateDiscount());
        panel.add(calculateDiscountBtn);
        
        payDueAmountBtn = new JButton("Pay Due Amount");
        payDueAmountBtn.addActionListener(e -> payDueAmount());
        panel.add(payDueAmountBtn);
                      
        saveToFileBtn = new JButton("Save to File");
        saveToFileBtn.addActionListener(e -> saveToFile());
        panel.add(saveToFileBtn);
        
        return panel;
    }
    
    private void addRegularMember() 
    {
        try {
            int id = Integer.parseInt(idField.getText());
            
            // Check for duplicate ID
            for (GymMember member : members) 
            {
                if (member.getId() == id) 
                {
                    JOptionPane.showMessageDialog(frame, "Member ID already exists!", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }
            
            String name = nameField.getText();
            String location = locationField.getText();
            String phone = phoneField.getText();
            String email = emailField.getText();
            
            // Get selected gender
            String gender = "";
            if (maleRadio.isSelected()) gender = "Male";
            else if (femaleRadio.isSelected()) gender = "Female";
            else if (otherRadio.isSelected()) gender = "Other";
            
            String dob = dobYearCombo.getSelectedItem() + "-" + 
                         dobMonthCombo.getSelectedItem() + "-" + 
                         dobDayCombo.getSelectedItem();
            
            String startDate = msYearCombo.getSelectedItem() + "-" + 
                              msMonthCombo.getSelectedItem() + "-" + 
                              msDayCombo.getSelectedItem();
            
            String referralSource = referralSourceField.getText();
            
            RegularMember member = new RegularMember(id, name, location, phone, email, gender, dob, startDate, referralSource);
            members.add(member);
            
            JOptionPane.showMessageDialog(frame, "Regular member added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException e) 
        {
            JOptionPane.showMessageDialog(frame, "Invalid ID format!", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e)
        {
            JOptionPane.showMessageDialog(frame, "Error adding member: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void addPremiumMember() 
    {
        try {
            int id = Integer.parseInt(idField.getText());
            
            // Check for duplicate ID
            for (GymMember member : members) 
            {
                if (member.getId() == id) 
                {
                    JOptionPane.showMessageDialog(frame, "Member ID already exists!", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }
            
            String name = nameField.getText();
            String location = locationField.getText();
            String phone = phoneField.getText();
            String email = emailField.getText();
            
            // Get selected gender
            String gender = "";
            if (maleRadio.isSelected()) gender = "Male";
            else if (femaleRadio.isSelected()) gender = "Female";
            else if (otherRadio.isSelected()) gender = "Other";
            
            String dob = dobYearCombo.getSelectedItem() + "-" + 
                         dobMonthCombo.getSelectedItem() + "-" + 
                         dobDayCombo.getSelectedItem();
    
            String startDate = msYearCombo.getSelectedItem() + "-" + 
                              msMonthCombo.getSelectedItem() + "-" + 
                              msDayCombo.getSelectedItem();
            String trainerName = trainerNameField.getText();
            PremiumMember member = new PremiumMember(id, name, location, phone, email, gender, dob, startDate, trainerName);
            members.add(member);
            
            JOptionPane.showMessageDialog(frame, "Premium member added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException e) 
        {
            JOptionPane.showMessageDialog(frame, "Invalid ID format!", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e)
        {
            JOptionPane.showMessageDialog(frame, "Error adding member: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void activateMembership() 
    {
        try {
            int id = Integer.parseInt(idField.getText());
            
            for (GymMember member : members) 
            {
                if (member.getId() == id) 
                {
                    member.activateMembership();
                    JOptionPane.showMessageDialog(frame, "Membership activated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    return;
                }
            }
            
            JOptionPane.showMessageDialog(frame, "Member ID not found!", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(frame, "Invalid ID format!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void deactivateMembership()
    {
        try {
            int id = Integer.parseInt(idField.getText());
            String reason = removalReasonField.getText();
            
            for (GymMember member : members)
            {
                if (member.getId() == id) 
                {
                    member.deactivateMembership();
                    JOptionPane.showMessageDialog(frame, "Membership deactivated successfully!", "Success",
                    JOptionPane.INFORMATION_MESSAGE);
                    return;
                }
            }
            
            JOptionPane.showMessageDialog(frame, "Member ID not found!", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (NumberFormatException e) 
        {
            JOptionPane.showMessageDialog(frame, "Invalid ID format!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void markAttendance() 
    {
        try {
            int id = Integer.parseInt(idField.getText());
            
            for (GymMember member : members)
            {
                if (member.getId() == id)
                {
                    {
                        member.markAttendance();
                        JOptionPane.showMessageDialog(frame, "Attendance marked successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    } 
                    
                    return;
                }
            }
            
            JOptionPane.showMessageDialog(frame, "Member ID not found!", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (NumberFormatException e) 
        {
            JOptionPane.showMessageDialog(frame, "Invalid ID format!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void revertRegularMember()
    {
        try {
            int id = Integer.parseInt(idField.getText());
            String reason = removalReasonField.getText();
            
            for (GymMember member : members)
            {
                if (member.getId() == id && member instanceof RegularMember) 
                {
                    ((RegularMember)member).revertRegularMember(reason);
                    JOptionPane.showMessageDialog(frame, "Regular member reverted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    return;
                }
            }
            
            JOptionPane.showMessageDialog(frame, "Regular member ID not found!", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (NumberFormatException e) 
        {
            JOptionPane.showMessageDialog(frame, "Invalid ID format!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void revertPremiumMember() 
    {
        try {
            int id = Integer.parseInt(idField.getText());
            
            for (GymMember member : members) 
            {
                if (member.getId() == id && member instanceof PremiumMember) 
                {
                    ((PremiumMember)member).revertPremiumMember();
                    JOptionPane.showMessageDialog(frame, "Premium member reverted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    return;
                }
            }
            
            JOptionPane.showMessageDialog(frame, "Premium member ID not found!", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (NumberFormatException e)
        {
            JOptionPane.showMessageDialog(frame, "Invalid ID format!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void calculateDiscount()
    {
        try {
            int id = Integer.parseInt(idField.getText());
            for (GymMember member : members) {
            if (member.getId() == id) {
                double discount = 0;
                if (member instanceof RegularMember) {
                    discount = 500;
                } else if (member instanceof PremiumMember) {
                    discount = 2000;
                }
                discountAmountField.setText(String.valueOf(discount));
                JOptionPane.showMessageDialog(frame, "Discount calculated: " + discount, "Discount", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
        }
        JOptionPane.showMessageDialog(frame, "Member ID not found!", "Error", JOptionPane.ERROR_MESSAGE);
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(frame, "Invalid ID format!", "Error", JOptionPane.ERROR_MESSAGE);
    }
    }

    private void payDueAmount() {
    try {
        int id = Integer.parseInt(idField.getText());
        for (GymMember member : members) {
            if (member.getId() == id) {
                double amountDue = 0;
                if (member instanceof RegularMember) {
                    amountDue = 6500 - Double.parseDouble(discountAmountField.getText());
                } else if (member instanceof PremiumMember) {
                    amountDue = 50000 - Double.parseDouble(discountAmountField.getText());
                }
                JOptionPane.showMessageDialog(frame, 
                    "Payment processed successfully!\nAmount paid: " + amountDue, 
                    "Payment", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
        }
        JOptionPane.showMessageDialog(frame, "Member ID not found!", "Error", JOptionPane.ERROR_MESSAGE);
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(frame, "Invalid ID format!", "Error", JOptionPane.ERROR_MESSAGE);
    } catch (Exception e) {
        JOptionPane.showMessageDialog(frame, "Error processing payment: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
    }

    private void saveToFile() {
    try {
        if (members.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "No members to save!", "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Save Member Data");
        int userSelection = fileChooser.showSaveDialog(frame);
        
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            java.io.File fileToSave = fileChooser.getSelectedFile();
            JOptionPane.showMessageDialog(frame, 
                "Member data saved to:\n" + fileToSave.getAbsolutePath(), 
                "Success", JOptionPane.INFORMATION_MESSAGE);
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(frame, "Error saving to file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
    }
    
    private void upgradePlan() {
        try {
            int id = Integer.parseInt(idField.getText());
            String newPlan = (String) planCombo.getSelectedItem();

            for (GymMember member : members) {
                if (member.getId() == id && member instanceof RegularMember) {
                    RegularMember regularMember = (RegularMember) member;
                    String result = regularMember.upgradePlan(newPlan);
                    JOptionPane.showMessageDialog(frame, result, "Upgrade Plan", JOptionPane.INFORMATION_MESSAGE);
                    return;
                }
            }

            JOptionPane.showMessageDialog(frame, "Regular Member ID not found!", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(frame, "Invalid ID format!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void displayMembers()
    {
    System.out.println("=== Displaying All Members ==="); 
    System.out.println("Total members: " + members.size());

    JFrame displayFrame = new JFrame("Member Information");
    displayFrame.setSize(600, 400);
    displayFrame.setLocationRelativeTo(this); 

    JTextArea textArea = new JTextArea();
    textArea.setEditable(false);
    JScrollPane scrollPane = new JScrollPane(textArea);

    textArea.append("Members List:\n\n");

    for (GymMember member : members)
    {
        if (member instanceof RegularMember) 
        {
            textArea.append("=== Regular Member ===\n");
            System.out.println("=== Regular Member ==="); 
        } else if (member instanceof PremiumMember) 
        {
            textArea.append("=== Premium Member ===\n");
            System.out.println("=== Premium Member ==="); 
        }

        textArea.append(member.toString() + "\n\n");
        System.out.println(member.toString()); 
        System.out.println(); 
    }

    displayFrame.add(scrollPane);
    displayFrame.setVisible(true);
    }
    
    
    private void clearFields() 
    {
        idField.setText("");
        nameField.setText("");
        locationField.setText("");
        phoneField.setText("");
        emailField.setText("");
        referralSourceField.setText("");
        paidAmountField.setText("");
        removalReasonField.setText("");
        trainerNameField.setText("");
        genderGroup.clearSelection();
        dobYearCombo.setSelectedIndex(0);
        dobMonthCombo.setSelectedIndex(0);
        dobDayCombo.setSelectedIndex(0);
        msYearCombo.setSelectedIndex(0);
        msMonthCombo.setSelectedIndex(0);
        msDayCombo.setSelectedIndex(0);
    }

}